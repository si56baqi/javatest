create view view_tree_cl_shebeixx as select '0'    AS `pkID`,
                                            '设备信息' AS `Name`,
                                            ''     AS `NO`,
                                            ''     AS `ParentID`,
                                            '设备信息' AS `TClass`
                                     union
                                     select `b`.`pkID`                                  AS `pkID`,
                                            concat(`b`.`MingCheng`, ' ', `b`.`XingHao`) AS `Name`,
                                            `b`.`pkID`                                  AS `NO`,
                                            '0'                                         AS `ParentID`,
                                            '设备'                                        AS `TClass`
                                     from `centerserviceplatform`.`cp_b_cheliangsb` `b`;

