create view view_cl_cheliangxh as (select `a`.`pkID`                                      AS `pkId`,
                                          `a`.`pkID`                                      AS `code`,
                                          concat(`a`.`CheLiangPP`, '-', `a`.`CheLiangXH`) AS `description`,
                                          '39b45d7a-b292-4d3d-9eee-9ecb00b1278c'          AS `TypeCode`
                                   from `centerserviceplatform`.`cp_b_chexingcs` `a`);

