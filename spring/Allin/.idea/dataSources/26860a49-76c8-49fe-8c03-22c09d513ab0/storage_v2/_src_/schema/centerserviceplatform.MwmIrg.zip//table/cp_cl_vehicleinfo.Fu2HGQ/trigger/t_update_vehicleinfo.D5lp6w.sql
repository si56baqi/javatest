create definer = root@`%` trigger T_Update_VehicleInfo
  before UPDATE
  on cp_cl_vehicleinfo
  for each row
BEGIN
	-- SELECT `NO` INTO @chehao FROM cp_cl_vehicleinfo WHERE pkID = new.fkID_VehicleInfo;
	SELECT `XuKeZH`,`OrgNO` INTO @xukezh,@orgno FROM cp_s_organization WHERE pkID = new.fkID_Org;
	SET new.OrgNO = @orgno;
	
	-- 更新车辆在线状态时同步更新车辆实时表状态
	update `cp_yyjk_liveinfo` set `connStatus` = new.`connStatus` where `fkID_VehicleInfo` = new.`pkID`;
    END;

