create view view_ry_sijixx as (select `sjxx`.`pkID`                          AS `pkId`,
                                      `sjxx`.`pkID`                          AS `code`,
                                      `sjxx`.`Name`                          AS `description`,
                                      `sjxx`.`ShenFenZH`                     AS `ShenFenZH`,
                                      `sjxx`.`Address`                       AS `Address`,
                                      '4b979e97-425c-4232-827a-9ecd00a51e73' AS `TypeCode`
                               from `centerserviceplatform`.`cp_ry_driverinfo` `sjxx`);

