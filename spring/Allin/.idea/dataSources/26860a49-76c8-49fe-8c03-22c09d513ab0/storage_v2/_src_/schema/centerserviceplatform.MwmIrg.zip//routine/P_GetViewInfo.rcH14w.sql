create
  definer = root@`%` procedure P_GetViewInfo(IN viewname varchar(60))
BEGIN
	-- 利用SET声明参数
	SET @ViewName = viewname;
	-- select @ViewName; -- 打印@ViewName变量
	/*
	if @viewname = '' or @viewname is null
	begin
	end
	*/
	SET @sql = CONCAT('SELECT * FROM ',@ViewName);
	-- select concat('构造的@sql语句--',@sql) as _temp; -- 打印@sql变量
	PREPARE stmtquery FROM @sql;
	execute stmtquery;
	-- EXECUTE stmtquery USING @ViewName;
	DEALLOCATE PREPARE stmtquery;
    END;

