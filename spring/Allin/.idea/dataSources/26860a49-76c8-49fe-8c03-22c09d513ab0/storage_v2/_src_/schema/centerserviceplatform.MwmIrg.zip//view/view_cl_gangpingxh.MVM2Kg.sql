create view view_cl_gangpingxh as
select `a`.`pkID`                                        AS `pkId`,
       `a`.`pkID`                                        AS `code`,
       concat(`a`.`GangPingXH`, '--', `a`.`ShengChanCJ`) AS `description`,
       '5b697a98-0030-4bc3-bf90-9ecb00e6b5eb'            AS `TypeCode`
from `centerserviceplatform`.`cp_b_gangpingcs` `a`;

