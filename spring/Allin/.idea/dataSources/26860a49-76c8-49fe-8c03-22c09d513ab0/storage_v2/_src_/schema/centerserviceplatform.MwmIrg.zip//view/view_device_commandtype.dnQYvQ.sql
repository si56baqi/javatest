create view view_device_commandtype as (select `a`.`pkID`                             AS `pkID`,
                                               `a`.`pkID`                             AS `code`,
                                               `a`.`commandZH`                        AS `description`,
                                               '8b1c348d-fa74-4460-b605-62b747159df2' AS `TypeCode`
                                        from `centerserviceplatform`.`cp_b_commandtype` `a`);

