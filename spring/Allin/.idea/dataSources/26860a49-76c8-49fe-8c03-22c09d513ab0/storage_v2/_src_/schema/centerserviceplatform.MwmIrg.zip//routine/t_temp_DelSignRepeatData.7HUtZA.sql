create
  definer = root@`%` procedure t_temp_DelSignRepeatData()
BEGIN
	/*
		测试用游标遍历删除重复数据
	*/
	
	-- 定义接收游标数据的变量 
	DECLARE n VARCHAR(20);
			
	DECLARE xulieH CHAR(36);	-- 设备序列号
	DECLARE chehao CHAR(36);	-- 车号
	DECLARE sigTime DATETIME;	-- 上车时间
	DECLARE sigNum INT;		-- 登签重复次数
	DECLARE limitNum INT;
	-- DECLARE lon DECIMAL(20,15);
	-- DECLARE lat DECIMAL(20,15);		
	
	-- 游标结束标记
	DECLARE done INT DEFAULT 0;	
	
	-- 对游标进行定义
	-- DECLARE cur CURSOR FOR SELECT ClientID, ICNO, signTime, longitude, latitude FROM `cp_yygl_signinfo` WHERE signType = '2' ORDER BY signTime DESC LIMIT 0,15000;
	DECLARE cur CURSOR FOR 
	SELECT a.`ClientID`, a.`CH_CheHao`,a.`signTime`,COUNT(a.`signTime`) AS `cs` FROM `cp_yygl_signinfo` a
        GROUP BY a.`ClientID`,a.`CH_CheHao`,a.`signTime` HAVING cs> 1 ORDER BY cs DESC LIMIT 0,2000;
	
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; /*这个是个条件处理,针对NOT FOUND的条件,当没有记录时赋值为1*/
	
	OPEN cur; /*接着使用OPEN打开游标*/	
	-- fETCH cur INTO n, ic; /*把第一行数据写入变量中,游标也随之指向了记录的第一行*/
	FETCH cur INTO xulieH, chehao, sigTime, sigNum;
	WHILE done != 1 DO
		-- set @a = id;
		-- set @icno = ic;	
		-- 这里做你想做的循环的事件
		-- insert into account(id,phone,password,name) value(UUID(),phone1,password1,CONCAT(name1,'的家长'));
		SET limitNum = sigNum - 1;
		-- 判断删除重复数据
		DELETE FROM `cp_yygl_signinfo` WHERE `ClientID` = xulieH AND `CH_CheHao`= chehao AND `signTime` = sigTime LIMIT limitNum;
		
		-- 提取游标数据
		FETCH cur INTO xulieH, chehao, sigTime, sigNum;
		
	END WHILE;
	
	CLOSE cur;  /*用完后记得用CLOSE把资源释放掉*/
    END;

