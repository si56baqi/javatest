create view view_cl_cheliangxx_all as (select `cl`.`pkID`                            AS `pkId`,
                                              `cl`.`pkID`                            AS `code`,
                                              `cl`.`NO`                              AS `description`,
                                              (case `cl`.`D_Status`
                                                 when '01' then '运营车辆'
                                                 when '02' then '报废车辆'
                                                 when '03' then '报停车辆'
                                                 when '04' then '闲置车辆'
                                                 else '' end)                        AS `CheLiangZT`,
                                              ifnull(`clxh`.`description`, '')       AS `CLXH`,
                                              '7203cbf0-981c-4279-b92a-a06000eccbca' AS `typeCode`
                                       from (`centerserviceplatform`.`cp_cl_vehicleinfo` `cl`
                                              left join `centerserviceplatform`.`view_cl_cheliangxh` `clxh`
                                                        on ((`cl`.`D_CheLiangXH` = `clxh`.`code`))));

