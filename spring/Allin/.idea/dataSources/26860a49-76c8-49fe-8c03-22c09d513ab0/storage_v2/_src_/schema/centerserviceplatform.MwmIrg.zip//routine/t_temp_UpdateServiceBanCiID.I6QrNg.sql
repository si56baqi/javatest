create
  definer = root@`%` procedure t_temp_UpdateServiceBanCiID()
BEGIN
	DECLARE n VARCHAR(20);  
	-- declare ic varchar(20);
	-- 定义接收游标数据的变量 
	DECLARE id CHAR(36);
	
	/*
	-- DECLARE ic CHAR(36);
	DECLARE sgInTime DATETIME;
	DECLARE sgOutTime DATETIME;
	DECLARE openTime DATETIME;
	DECLARE closeTime DATETIME;
	DECLARE sCount INT;
	DECLARE xlh CHAR(30);
	DECLARE clid CHAR(36);
	*/
	
	-- DECLARE lon DECIMAL(20,15);
	-- DECLARE lat DECIMAL(20,15);
	
	-- 游标结束标记
	DECLARE done INT DEFAULT 0;	
	-- DECLARE cur CURSOR FOR SELECT `Name`, `ICNO` from `cp_ry_driverinfo`;  -- 首先这里对游标进行定义
	DECLARE cur CURSOR FOR SELECT a.`pkID` FROM `cp_yygl_serviceinfo` a WHERE (a.`fkID_BanCiXX` IS NULL OR a.`fkID_BanCiXX` = '') AND a.`getOnCarTime` < '2017-01-01 00:00:00' ORDER BY a.`getOnCarTime` DESC limit 0,5000;
	-- 这个是个条件处理,针对NOT FOUND的条件,当没有记录时赋值为1
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;
	-- 接着使用OPEN打开游标
	OPEN cur; 	
	-- fETCH cur INTO n, ic; -- 把第一行数据写入变量中,游标也随之指向了记录的第一行
	FETCH cur INTO id;
	WHILE done != 1 DO	   
		UPDATE `cp_yygl_serviceinfo` a,`cp_yygl_bancixx` b
		   SET a.`ICNO` = b.`ICNO`,
		       a.`fkID_DriverInfo`=b.`fkID_DriverInfo`,
		       a.`D_SiJiBanBie` = b.`D_SiJiBanBie`,
		       a.`CH_Name` = b.`CH_Name`,
		       a.`fkID_BanCiXX` = b.`pkID`
		 WHERE a.`fkID_VehicleInfo` = b.`fkID_VehicleInfo`
		   AND (a.`fkID_BanCiXX` IS NULL OR a.`fkID_BanCiXX` = '')
		   AND a.`getOnCarTime` >= b.`meterOpenTime`
		   AND a.`getOffCarTime` <= b.`meterCloseTime`
		   AND a.`pkID` = id;
		   
		FETCH cur INTO id;
	END WHILE;
	CLOSE cur;  -- 用完后记得用CLOSE把资源释放掉
    END;

