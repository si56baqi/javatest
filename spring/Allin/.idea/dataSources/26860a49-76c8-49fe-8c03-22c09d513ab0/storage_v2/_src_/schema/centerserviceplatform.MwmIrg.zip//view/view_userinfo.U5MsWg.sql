create view view_userinfo as (select `u`.`pkID`                             AS `pkId`,
                                     `u`.`pkID`                             AS `code`,
                                     `u`.`Name`                             AS `description`,
                                     `u`.`NO`                               AS `no`,
                                     '1a7ec48e-6bb6-11e7-b2b6-e03f491c16cf' AS `TypeCode`
                              from `centerserviceplatform`.`cp_s_userinfo` `u`
                              where (`u`.`NO` <> 'admin'));

