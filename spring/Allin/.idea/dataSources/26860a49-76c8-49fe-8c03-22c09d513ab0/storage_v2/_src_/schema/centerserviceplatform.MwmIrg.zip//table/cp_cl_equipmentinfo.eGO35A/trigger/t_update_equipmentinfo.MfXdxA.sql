create definer = root@`%` trigger T_Update_EquipmentInfo
  before UPDATE
  on cp_cl_equipmentinfo
  for each row
BEGIN
  	IF new.fkID_VehicleInfo = '' THEN
		SET @chehao := '';
		-- 更新车辆表里对应的终端序列号为空
		update cp_cl_vehicleinfo set CH_XuLieH = '' where CH_XuLieH = new.XuLieH;		
	ELSE
		SELECT `NO` INTO @chehao FROM cp_cl_vehicleinfo WHERE pkID = new.fkID_VehicleInfo;
		/* 设置当前行数据 */
		SET new.CH_CheHao = @chehao;	
		/* 更新车辆表对应的终端序列号 */
		UPDATE cp_cl_vehicleinfo SET CH_XuLieH = new.XuLieH WHERE pkID = new.fkID_VehicleInfo;
		/* 判断更新终端验证表 */	
		select count(*) into @i from apn_user where `username` = new.XuLieH;
		if @i > 0 then
			update apn_user set `name` = @chehao where `username` = new.XuLieH;
		else
			INSERT INTO apn_user(`created_date`,`name`,`password`,`username`) VALUES(NOW(),@chehao,'taxi123',new.XuLieH);
		end if;		
		/*判断更新车辆实况信息表*/ 
		SELECT COUNT(*) INTO @i FROM `cp_yyjk_liveinfo` WHERE fkID_VehicleInfo = new.fkID_VehicleInfo;
		IF @i > 0 THEN
			UPDATE `cp_yyjk_liveinfo` SET ClientID = new.XuLieH,fkID_VehicleInfo = new.fkID_VehicleInfo, CH_CheHao = @chehao WHERE fkID_VehicleInfo = new.fkID_VehicleInfo;
		ELSE
			-- 同步更新车辆实况信息表
			INSERT INTO `cp_yyjk_liveinfo`(pkID,fkID_UserInfo,fkID_UserOrg,CreateTime,EditTime,EditUser,State,fkID_ParentKey,fkID,WorkFlowID,fkID_VehicleInfo,ClientID,CH_CheHao)
			VALUES(new.`pkID`,new.`fkID_UserInfo`,new.`fkID_UserOrg`,new.`CreateTime`,new.`EditTime`,new.`EditUser`,new.`State`,new.`fkID_ParentKey`,new.`fkID`,new.`WorkFlowID`,new.`fkID_VehicleInfo`,new.`XuLieH`,new.`CH_CheHao`);			
		END IF;	
	END IF;
	-- 终端初始化给apn_user表里同步信息
	-- update apn_user set `name` = @chehao where `username` = new.XuLieH;
    END;

