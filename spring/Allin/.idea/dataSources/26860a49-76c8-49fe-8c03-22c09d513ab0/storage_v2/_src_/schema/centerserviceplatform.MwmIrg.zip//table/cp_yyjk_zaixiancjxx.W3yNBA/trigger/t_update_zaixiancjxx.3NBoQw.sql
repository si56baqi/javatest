create definer = root@`%` trigger T_Update_ZaiXianCJXX
  after UPDATE
  on cp_yyjk_zaixiancjxx
  for each row
BEGIN
	if new.`PaiZhaoZT` = '1' and new.`photoImg` is not null and new.`photoImg` != '' then
		-- 统计当前车辆拍照次数
		select ifnull(count(pkID),0) into @iCount from `cp_yyjk_zaixiancjxx` where `fkID_VehicleInfo` = new.`fkID_VehicleInfo`;
		update `cp_cl_vehicleinfo` set `paizhaoCS` = @iCount where `pkID` = new.`fkID_VehicleInfo`;
	end if;
    END;

