create
  definer = root@`%` procedure t_temp_UpdateServiceBanCiXX()
BEGIN
	/*
		测试用游标 遍历更新表数据
	*/
	DECLARE n VARCHAR(20);  
	-- declare ic varchar(20);
	-- 定义接收游标数据的变量 
	DECLARE id CHAR(36);
	-- DECLARE ic CHAR(36);
	DECLARE sgInTime DATETIME;
	DECLARE sgOutTime DATETIME;
	DECLARE openTime DATETIME;
	DECLARE closeTime DATETIME;
	declare sCount int;
	declare xlh char(30);
	DECLARE clid CHAR(36);
	
	-- DECLARE lon DECIMAL(20,15);
	-- DECLARE lat DECIMAL(20,15);
	
	-- 游标结束标记
	DECLARE done INT DEFAULT 0;	
	-- DECLARE cur CURSOR FOR SELECT `Name`, `ICNO` from `cp_ry_driverinfo`;  -- 首先这里对游标进行定义
	DECLARE cur CURSOR FOR 
	SELECT `pkID`,`signInTime`,`signOutTime`,`meterOpenTime`,`meterCloseTime`,`serviceCount`,`ClientID`,`fkID_VehicleInfo` FROM `cp_yygl_bancixx` ORDER BY `signOutTime` DESC LIMIT 0,27000;
		
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; -- 这个是个条件处理,针对NOT FOUND的条件,当没有记录时赋值为1
	OPEN cur; -- 接着使用OPEN打开游标	
	-- fETCH cur INTO n, ic; -- 把第一行数据写入变量中,游标也随之指向了记录的第一行
	FETCH cur INTO id, sgInTime, sgOutTime, openTime, closeTime,sCount,xlh,clid;
	WHILE done != 1 DO
		UPDATE `cp_yygl_serviceinfo` SET `fkID_BanCiXX` = id
		 WHERE `fkID_VehicleInfo` = clid 
		   AND `getOnCarTime` >= openTime
		   and `getOffCarTime` <= closeTime  ;	
		FETCH cur INTO id, sgInTime, sgOutTime, openTime, closeTime,sCount,xlh,clid;
	END WHILE;
	CLOSE cur;  -- 用完后记得用CLOSE把资源释放掉
    END;

