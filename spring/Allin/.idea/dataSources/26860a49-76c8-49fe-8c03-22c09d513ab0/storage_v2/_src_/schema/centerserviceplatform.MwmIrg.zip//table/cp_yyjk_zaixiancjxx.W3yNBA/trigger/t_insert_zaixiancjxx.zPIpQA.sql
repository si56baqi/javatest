create definer = root@`%` trigger T_Insert_ZaiXianCJXX
  before INSERT
  on cp_yyjk_zaixiancjxx
  for each row
BEGIN
	if new.`ClientID` != '' then
		select `serviceICNO`,`serviceName`,`gpsWorkStatus` into @icno,@name,@work from `cp_yyjk_liveinfo` where `ClientID` = new.`ClientID`;
		select `pkID`,`fkID_Org`,`D_SiJiBanBie` into @ryID,@orgID,@banbie from `cp_ry_driverinfo` where `ICNO` = @icno;
		/* 设置当前行数据 */
		SET new.`fkID_Org`=@orgID, new.`fkID_DriverInfo`=@ryID, new.`ICNO`=@icno, new.`D_SiJiBanBie`=@banbie, new.`CH_Name`=@name, new.`workStatus`=@work;
	end if;
    END;

