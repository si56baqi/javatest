create
  definer = root@`%` function f_get_driverImg(clid varchar(36)) returns varchar(500)
BEGIN
	DECLARE ryID VARCHAR(36);
	DECLARE ryName VARCHAR(36);
	DECLARE ryIC VARCHAR(36);
	DECLARE ryPhoto VARCHAR(150);
	DECLARE ryImgInfo VARCHAR(500);
	DECLARE ryDone INT DEFAULT 0; -- 游标结束标记
	DECLARE ryCur CURSOR FOR SELECT `pkID`,`Name`,`ICNO`,`Photo` FROM `cp_ry_driverinfo` WHERE `fkID_VehicleInfo` = clid order by D_SiJiBanBie; -- 定义游标
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET ryDone = 1;
	SET ryImgInfo := '';
	OPEN ryCur; -- 打开游标
	FETCH ryCur INTO ryID,ryName,ryIC,ryPhoto;
	WHILE ryDone != 1 DO
		IF ryImgInfo = '' THEN
			SET ryImgInfo := CONCAT(ryName,'#',ryPhoto);
		ELSE
			SET ryImgInfo := CONCAT(ryImgInfo,'|',ryName,'#',ryPhoto);
		END IF;
		-- 提取人员信息
		FETCH ryCur INTO ryID,ryName,ryIC,ryPhoto;
	END WHILE;
	CLOSE ryCur; -- 关闭游标
	-- 返回值
	return(ryImgInfo);
    END;

