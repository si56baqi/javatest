create view view_cl_cheliangxx as (select `cl`.`pkID`                            AS `pkId`,
                                          `cl`.`pkID`                            AS `code`,
                                          `cl`.`NO`                              AS `description`,
                                          `clxh`.`description`                   AS `CLXH`,
                                          '92a3a681-69a8-41ef-82bd-9ecb00f42519' AS `TypeCode`
                                   from (`centerserviceplatform`.`cp_cl_vehicleinfo` `cl`
                                          left join `centerserviceplatform`.`view_cl_cheliangxh` `clxh`
                                                    on ((`cl`.`D_CheLiangXH` = `clxh`.`code`)))
                                   where (`cl`.`D_Status` <> '02'));

