create view view_device_init_info as (select `a`.`XuLieH`    AS `XuLieH`,
                                             `b`.`ShortName` AS `OrgName`,
                                             `b`.`XuKeZH`    AS `XuKeZH`,
                                             `c`.`NO`        AS `CarNO`,
                                             `b`.`pkID`      AS `OrgPkID`,
                                             `c`.`pkID`      AS `CarPkID`,
                                             `a`.`pkID`      AS `DevicePkID`
                                      from ((`centerserviceplatform`.`cp_cl_equipmentinfo` `a` join `centerserviceplatform`.`cp_s_organization` `b`)
                                             join `centerserviceplatform`.`cp_cl_vehicleinfo` `c`)
                                      where ((`c`.`fkID_Org` = `b`.`pkID`) and (`a`.`fkID_Org` = `b`.`pkID`) and
                                             (`c`.`pkID` = `a`.`fkID_VehicleInfo`)));

