create view view_s_appinfo as (select `a`.`pkID`                             AS `pkId`,
                                      `a`.`pkID`                             AS `code`,
                                      `a`.`filename`                         AS `description`,
                                      'd11fcc04-f8ca-11e5-ba11-e03f491c16cf' AS `typeCode`
                               from `centerserviceplatform`.`cp_s_appinfo` `a`);

