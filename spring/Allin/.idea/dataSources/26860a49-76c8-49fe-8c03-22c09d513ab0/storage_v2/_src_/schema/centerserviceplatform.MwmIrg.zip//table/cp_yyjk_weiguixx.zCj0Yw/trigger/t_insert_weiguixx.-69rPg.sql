create definer = root@`%` trigger T_Insert_WeiGuiXX
  after INSERT
  on cp_yyjk_weiguixx
  for each row
BEGIN
	-- 统计当前车辆的所有违规信息
	select ifnull(count(pkID),0) into @iCount from `cp_yyjk_weiguixx` where `fkID_VehicleInfo` = new.`fkID_VehicleInfo`;
	update `cp_cl_vehicleinfo` set `weiguiSJ` = @iCount where `pkID` = new.`fkID_VehicleInfo`;
    END;

