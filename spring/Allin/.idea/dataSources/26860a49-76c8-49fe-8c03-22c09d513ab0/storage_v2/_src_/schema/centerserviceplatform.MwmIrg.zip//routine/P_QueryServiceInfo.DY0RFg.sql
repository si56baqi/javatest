create
  definer = root@`%` procedure P_QueryServiceInfo(IN m int, IN n int)
BEGIN
	/*
		此存储过程暂不用
		使用游标与游标之间的嵌套使用，查询对应的数据
	*/
	-- 定义接收游标数据的变量 
	-- DECLARE nn VARCHAR(20);  	
	declare	id VARCHAR(36);
	DECLARE	cTime DATETIME;
	DECLARE	ic VARCHAR(36);
	DECLARE	sbId VARCHAR(36);
	DECLARE	fkIdCL VARCHAR(36);
	DECLARE	fkIdRY VARCHAR(36);
	DECLARE	onTime DATETIME;
	DECLARE	offTime DATETIME;
	DECLARE	byMeter DECIMAL(18,2);
	DECLARE	emptyMetre DECIMAL(18,2);
	DECLARE	money DECIMAL(18,2);
	DECLARE	fjf DECIMAL(18,2);
	DECLARE	onImg VARCHAR(128);
	DECLARE	offImg VARCHAR(128);
	DECLARE	flg CHAR(1);
	DECLARE	chCheHao VARCHAR(36);
	DECLARE	chName VARCHAR(36);
	DECLARE	fkIdBanCi VARCHAR(36);
	
	DECLARE done INT DEFAULT 0; -- 游标结束标记	
	-- DECLARE cur CURSOR FOR SELECT `Name`, `ICNO` from `cp_ry_driverinfo`;  /*首先这里对游标进行定义*/
	DECLARE cur CURSOR FOR SELECT pkID,CreateTime,ICNO,ClientID,fkID_VehicleInfo,fkID_DriverInfo,getOnCarTime,getOffCarTime,byMeterKilometre,emptyKilometre,dealMoney,additionalFee,getOnImg,getOffImg,flag,CH_CheHao,CH_Name,fkID_BanCiXX FROM `cp_yygl_serviceinfo` WHERE 1=1 ORDER BY CreateTime DESC LIMIT m,n;	
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; /*这个是个条件处理,针对NOT FOUND的条件,当没有记录时赋值为1*/
	-- 创建临时表
	CREATE TEMPORARY TABLE IF NOT EXISTS temp_ServiceInfo(
		pkID varchar(36),
		CreateTime datetime,
		ICNO VARCHAR(36),
		ClientID VARCHAR(36),
		fkID_VehicleInfo VARCHAR(36),
		fkID_DriverInfo VARCHAR(36),
		getOnCarTime datetime,
		getOffCarTime datetime,
		byMeterKilometre decimal(18,2),
		emptyKilometre decimal(18,2),
		dealMoney decimal(18,2),
		additionalFee decimal(18,2),
		getOnImg varchar(128),
		getOffImg varchar(128),
		flag char(1),
		CH_CheHao VARCHAR(36),
		CH_Name VARCHAR(36),
		fkID_BanCiXX VARCHAR(36),
		ryImg varchar(512)
	);
	truncate TABLE temp_ServiceInfo; /*使用前先清空临时表*/
	OPEN cur; /*接着使用OPEN打开游标*/	
	-- 把第一行数据写入变量中,游标也随之指向了记录的第一行
	FETCH cur INTO id,cTime,ic,sbId,fkIdCL,fkIdRY,onTime,offTime,byMeter,emptyMetre,money,fjf,onImg,offImg,flg,chCheHao,chName,fkIdBanCi;
	WHILE done != 1 DO
		-- 给临时表里插入数据
		insert into temp_ServiceInfo values(id,cTime,ic,sbId,fkIdCL,fkIdRY,onTime,offTime,byMeter,emptyMetre,money,fjf,onImg,offImg,flg,chCheHao,chName,fkIdBanCi,'');
		
		-- 嵌套子游标查询每辆车对应的人员信息
		begin			
			declare ryID varchar(36);
			declare ryName varchar(36);
			declare ryIC varchar(36);
			declare ryPhoto varchar(150);
			declare ryImgInfo varchar(500);
			DECLARE ryDone INT DEFAULT 0; -- 游标结束标记
			DECLARE ryCur CURSOR FOR select `pkID`,`Name`,`ICNO`,`Photo` from `cp_ry_driverinfo` where `fkID_VehicleInfo` = fkIdCL; -- 定义游标
			DECLARE CONTINUE HANDLER FOR NOT FOUND SET ryDone = 1;
			set ryImgInfo := '';
			OPEN ryCur;
			FETCH ryCur into ryID,ryName,ryIC,ryPhoto;
			WHILE ryDone != 1 DO
				if ryImgInfo = '' then
					SET ryImgInfo := CONCAT(ryName,'_',ryPhoto);
				else
					set ryImgInfo := CONCAT(ryImgInfo,'|',ryName,'_',ryPhoto);
				end if;
				-- 提取人员信息
				FETCH ryCur INTO ryID,ryName,ryIC,ryPhoto;
			end while;
			close ryCur;
			update temp_ServiceInfo set ryImg = ryImgInfo where fkID_VehicleInfo = fkIdCL;
		end;
		-- /.end 嵌套子游标结束
		
		-- 提取营运数据信息
		FETCH cur INTO id,cTime,ic,sbId,fkIdCL,fkIdRY,onTime,offTime,byMeter,emptyMetre,money,fjf,onImg,offImg,flg,chCheHao,chName,fkIdBanCi;		
	END WHILE;
	CLOSE cur; -- 用完后记得用CLOSE把资源释放掉
	select * from temp_ServiceInfo order by CreateTime;
    END;

