create definer = root@`%` trigger T_Update_SignInfoSummary
  after UPDATE
  on cp_yygl_signinfosummary
  for each row
BEGIN
	if LENGTH(IFNULL(new.`flagAll`,'')) > LENGTH(IFNULL(old.`flagAll`,'')) then
		-- 获得当前照片阅读人员
		SET @fgName := SUBSTRING(IFNULL(new.`flagAll`,''),LENGTH(IFNULL(old.`flagAll`,''))+1);
		-- 统计当前车辆所有班次数
		-- select count(pkID) into @iCount from `cp_yygl_signinfosummary` where `fkID_VehicleInfo` = new.`fkID_VehicleInfo` and `signOutTime` != '' and `signOutTime` is not null;
		SELECT COUNT(pkID) INTO @iCount FROM `cp_yygl_signinfosummary` WHERE `fkID_VehicleInfo` = new.`fkID_VehicleInfo` AND `fkID_BanCiXX` != '' AND `fkID_BanCiXX` IS NOT NULL;
		-- 统计当前车辆照片已阅班次数
		SELECT COUNT(pkID) INTO @iOK FROM `cp_yygl_signinfosummary` WHERE `fkID_VehicleInfo` = new.`fkID_VehicleInfo` AND LOCATE(@fgName,`flagAll`) > 0; 
		IF @iOK = @iCount THEN
			SET @fgUser := IFNULL(@fgName,'');
			UPDATE `cp_cl_vehicleinfo` SET `flagAll` = CONCAT(IFNULL(`flagAll`,''),@fgUser) WHERE `pkID` = new.`fkID_VehicleInfo`;	
		END IF;	
	end if;
    END;

