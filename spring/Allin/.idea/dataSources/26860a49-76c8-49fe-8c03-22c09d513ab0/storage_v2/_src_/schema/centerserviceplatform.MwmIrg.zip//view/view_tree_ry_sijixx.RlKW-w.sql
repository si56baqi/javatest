create view view_tree_ry_sijixx as select '0'    AS `pkID`,
                                          '司机信息' AS `Name`,
                                          ''     AS `NO`,
                                          ''     AS `ParentID`,
                                          '司机信息' AS `TClass`
                                   union
                                   select `b`.`pkID` AS `pkID`,
                                          `b`.`Name` AS `Name`,
                                          `b`.`pkID` AS `NO`,
                                          '0'        AS `ParentID`,
                                          '司机'       AS `TClass`
                                   from `centerserviceplatform`.`cp_ry_driverinfo` `b`;

