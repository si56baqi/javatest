create definer = root@`%` trigger T_Insert_EquipmentInfo
  before INSERT
  on cp_cl_equipmentinfo
  for each row
BEGIN
	if new.fkID_VehicleInfo != '' then
		SELECT `NO` INTO @chehao FROM cp_cl_vehicleinfo WHERE pkID = new.fkID_VehicleInfo;
		-- 设置当前行数据
		SET new.CH_CheHao = @chehao;
		
		-- 更新车辆对应的设备序列号
		UPDATE cp_cl_vehicleinfo SET CH_XuLieH = new.XuLieH where pkID = new.fkID_VehicleInfo;
				
		-- apn_user表里同步信息
		insert into apn_user(`created_date`,`name`,`password`,`username`) values(NOW(),@chehao,'taxi123',new.XuLieH);
		
		/*判断更新车辆实况信息表*/ 
		select count(*) into @i from `cp_yyjk_liveinfo` where fkID_VehicleInfo = new.fkID_VehicleInfo;
		if @i > 0 then
			update `cp_yyjk_liveinfo` set ClientID = new.XuLieH,fkID_VehicleInfo = new.fkID_VehicleInfo, CH_CheHao = @chehao where fkID_VehicleInfo = new.fkID_VehicleInfo;
		else
			-- 同步更新车辆实况信息表
			INSERT INTO `cp_yyjk_liveinfo`(pkID,fkID_UserInfo,fkID_UserOrg,CreateTime,EditTime,EditUser,State,fkID_ParentKey,fkID,WorkFlowID,fkID_VehicleInfo,ClientID,CH_CheHao)
			values(new.`pkID`,new.`fkID_UserInfo`,new.`fkID_UserOrg`,new.`CreateTime`,new.`EditTime`,new.`EditUser`,'1',new.`fkID_ParentKey`,new.`fkID`,new.`WorkFlowID`,new.`fkID_VehicleInfo`,new.`XuLieH`,new.`CH_CheHao`);
			/*INSERT INTO `cp_yyjk_liveinfo`(pkID,fkID_UserInfo,fkID_UserOrg,CreateTime,EditTime,EditUser,State,fkID_ParentKey,fkID,WorkFlowID,fkID_VehicleInfo,ClientID,CH_CheHao)
			SELECT UUID() AS `pkID`,
			       '' AS fkID_UserInfo,
			       '' AS fkID_UserOrg,
			       NOW() AS CreateTime,
			       NOW() AS EditTime,
			       '' AS EditUser,
			       '00000000000000000000' AS State,
			       '' AS fkID_ParentKey,
			       '' AS fkID,
			       '' AS WorkFlowID,
			       new.fkID_VehicleInfo as fkID_VehicleInfo,
			       new.XuLieH as ClientID,
			       @chehao as CH_CheHao;*/
		end if;
	else
		-- apn_user表里同步信息
		INSERT INTO apn_user(`created_date`,`name`,`password`,`username`) VALUES(NOW(),'','taxi123',new.XuLieH);		
	end if;
    END;

