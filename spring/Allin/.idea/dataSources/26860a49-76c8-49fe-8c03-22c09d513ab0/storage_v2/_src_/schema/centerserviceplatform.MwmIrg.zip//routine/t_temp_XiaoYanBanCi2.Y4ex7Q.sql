create
  definer = root@`%` procedure t_temp_XiaoYanBanCi2()
BEGIN
	-- +++++++++++++++++++++++++++++++++++++++++++
	-- 检查校验班次信息营运次数大于30并且计价器开机时间带有秒的数据
	-- +++++++++++++++++++++++++++++++++++++++++++
	-- 定义接收游标数据的变量 
	DECLARE banciID VARCHAR(36);
	-- 游标结束标记
	DECLARE done INT DEFAULT 0;	
	-- 首先这里对游标进行定义
	DECLARE cur CURSOR FOR SELECT a.`pkID` FROM `cp_yygl_bancixx` a WHERE SUBSTRING(a.`meterOpenTime`,18) !='00' ORDER BY a.`meterCloseTime` DESC;
	-- 这个是个条件处理,针对NOT FOUND的条件,当没有记录时赋值为1
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; 
	-- 使用OPEN打开游标
	OPEN cur;	
	-- 把第一行数据写入变量中,游标也随之指向了记录的第一行
	FETCH cur INTO banciID;
	-- 开始遍历
	WHILE done != 1 DO	
	BEGIN
		UPDATE `cp_yygl_bancixx` b,
		       (SELECT COUNT(*) AS `次数`,SUM(a.`dealMoney`) AS `金额`,SUM(a.`byMeterKilometre`) AS `营运里程`,SUM(a.`byMeterKilometre`+a.`emptyKilometre`) AS `行驶里程`
			  FROM centerserviceplatform.`cp_yygl_serviceinfo` a
			 WHERE a.`fkID_BanCiXX` = banciID) a
		   SET b.`carNumber` = a.`次数`,
		       b.`serviceCount` = a.`次数`,
		       b.`amountMoney` = a.`金额`,
		       b.`workKilometre` = a.`行驶里程`,
		       b.`serviceKilometre` = a.`营运里程`,
		       b.`meterOpenTime` = CONCAT(SUBSTRING(b.`signInTime`,1,LENGTH(b.`signInTime`)-2),'00'),
		       b.`State` = CONCAT('1',SUBSTRING(b.`State`,2))
		 WHERE b.`pkID` = banciID;		
	end;
	end while;
	-- CLOSE把资源释放掉
	CLOSE cur;
    END;

