create definer = root@`%` event command_checkDelData on schedule
  every '1' DAY
    starts '2016-12-19 12:30:00'
  on completion preserve
  enable
  do
  BEGIN
	    CALL `P_DeleteCommandInfo`();
	END;

