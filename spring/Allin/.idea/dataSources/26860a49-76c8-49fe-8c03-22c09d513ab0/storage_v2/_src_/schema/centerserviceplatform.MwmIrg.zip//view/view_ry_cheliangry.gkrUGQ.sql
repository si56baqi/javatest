create view view_ry_cheliangry as select `cl`.`pkID` AS `pkID`, `cl`.`NO` AS `MC`
                                  from `centerserviceplatform`.`cp_cl_vehicleinfo` `cl`
                                  union
                                  select `sj`.`pkID` AS `pkID`, `sj`.`Name` AS `MC`
                                  from `centerserviceplatform`.`cp_ry_driverinfo` `sj`;

