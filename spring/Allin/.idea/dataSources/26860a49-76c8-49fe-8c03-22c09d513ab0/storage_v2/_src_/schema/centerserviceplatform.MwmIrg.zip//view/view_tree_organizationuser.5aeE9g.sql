create view view_tree_organizationuser as select `f`.`pkID`      AS `pkId`,
                                                 `f`.`Name`      AS `name`,
                                                 `f`.`NO`        AS `no`,
                                                 `f`.`ParentID`  AS `parentId`,
                                                 '机构'            AS `tclass`,
                                                 ''              AS `手机号码`,
                                                 ''              AS `邮箱`,
                                                 `f`.`NodeLevel` AS `nodeLevel`,
                                                 '1'             AS `ifUse`
                                          from `centerserviceplatform`.`cp_s_organization` `f`
                                          union
                                          select `u`.`pkID`     AS `pkId`,
                                                 `u`.`Name`     AS `name`,
                                                 `u`.`NO`       AS `no`,
                                                 `u`.`fkID_Org` AS `parentID`,
                                                 '人员'           AS `tclass`,
                                                 `u`.`Mobile`   AS `手机号码`,
                                                 `u`.`Email`    AS `邮箱`,
                                                 0              AS `nodeLevel`,
                                                 '1'            AS `ifUse`
                                          from `centerserviceplatform`.`cp_s_userinfo` `u`
                                          where (`u`.`NO` <> 'admin');

