create view view_cl_jijiaqxh as
select `a`.`pkID`                                     AS `pkID`,
       `a`.`pkID`                                     AS `code`,
       concat(`a`.`ShengChanCJ`, '--', `a`.`XingHao`) AS `description`,
       'fc5887b8-cf24-4b57-ab9a-9ecb00f73886'         AS `TypeCode`
from `centerserviceplatform`.`cp_b_jijiaqxh` `a`;

