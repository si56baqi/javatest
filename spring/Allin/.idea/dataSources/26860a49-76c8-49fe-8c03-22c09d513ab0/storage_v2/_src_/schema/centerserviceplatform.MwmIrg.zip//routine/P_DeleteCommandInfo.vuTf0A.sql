create
  definer = root@`%` procedure P_DeleteCommandInfo()
BEGIN
	-- 删除指令已接收完成的数据
	delete from `apn_notification` where `status`='2';
	delete from `cp_xxgl_taskinfo` where `status`='2';
    END;

