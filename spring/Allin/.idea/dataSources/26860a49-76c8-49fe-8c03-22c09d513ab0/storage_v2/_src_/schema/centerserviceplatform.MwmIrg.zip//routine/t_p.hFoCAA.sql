create
  definer = root@`%` procedure t_p()
BEGIN
	/*
		测试用游标 遍历更新表数据
	*/
	declare n varchar(20);  
	-- declare ic varchar(20);
	-- 定义接收游标数据的变量 
	DECLARE id CHAR(25);
	DECLARE ic CHAR(36);
	DECLARE sj DATETIME;
	DECLARE lon DECIMAL(20,15);
	DECLARE lat DECIMAL(20,15);		
	-- 游标结束标记
	DECLARE done INT DEFAULT 0;	
	-- DECLARE cur CURSOR FOR SELECT `Name`, `ICNO` from `cp_ry_driverinfo`;  /*首先这里对游标进行定义*/
	DECLARE cur CURSOR FOR SELECT ClientID, ICNO, signTime, longitude, latitude FROM `cp_yygl_signinfo` WHERE signType = '2' ORDER BY signTime DESC limit 0,15000;	
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; /*这个是个条件处理,针对NOT FOUND的条件,当没有记录时赋值为1*/
	OPEN cur; /*接着使用OPEN打开游标*/	
	-- fETCH cur INTO n, ic; /*把第一行数据写入变量中,游标也随之指向了记录的第一行*/
	FETCH cur INTO id, ic, sj, lon, lat;
	WHILE done != 1 DO
		-- set @a = id;
		-- set @icno = ic;	
		-- 这里做你想做的循环的事件
		-- insert into account(id,phone,password,name) value(UUID(),phone1,password1,CONCAT(name1,'的家长'));
		-- 判断更新登签汇总表
		SELECT COUNT(*) INTO @i FROM `cp_yygl_signinfo` WHERE `ClientID` = id AND `signType` = '1' AND sj >= `signTime` ORDER BY `signTime` DESC;
		IF @i > 0 THEN
			SET @signOutImg := IFNULL(CONCAT('/uploadFiles/photo/sign/',DATE_FORMAT(sj,'%Y-%m-%d'),'/',ic,'/',DATE_FORMAT(sj,'%Y%m%d%H%i%s'),'_0_2.jpg'),'');
			-- 查询最近一次签到信息
			SELECT `signTime` INTO @signI FROM `cp_yygl_signinfo` WHERE `ClientID` = id AND `signType` = '1' AND sj >= `signTime` ORDER BY `signTime` DESC LIMIT 1;
			-- 查询登签汇总表
			SELECT `signOutTime` INTO @nsignO FROM `cp_yygl_signinfosummary` WHERE `ClientID` = id AND `signInTime` = @signI LIMIT 1;
			-- 判断汇总表签退时间是否为空
			IF @nsignO = '' OR @nsignO IS NULL THEN					
				UPDATE `cp_yygl_signinfosummary` SET `signOutTime` = sj,`signOutLongitude` = lon,`signOutLatitude` = lat,`signOutImg` = @signOutImg WHERE `ClientID` = id AND `signInTime` = @signI;
			END IF;
		END IF;		
		FETCH cur INTO id, ic, sj, lon, lat;
	end while;
	CLOSE cur;  /*用完后记得用CLOSE把资源释放掉*/
    END;

