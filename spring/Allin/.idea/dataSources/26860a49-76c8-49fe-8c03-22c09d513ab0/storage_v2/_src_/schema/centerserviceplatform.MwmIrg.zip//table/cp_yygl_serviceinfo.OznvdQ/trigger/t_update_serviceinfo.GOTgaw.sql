create definer = root@`%` trigger T_Update_ServiceInfo
  after UPDATE
  on cp_yygl_serviceinfo
  for each row
BEGIN
	/* 根据设备序列号查询车号、车主键*/
	IF new.ClientID = '' THEN
		SET @clID := '',@clNO := '',@orgID := '';
	ELSE		
		SELECT A.`pkID`,A.`NO`,A.`fkID_Org` INTO @clID,@clNO,@orgID FROM cp_cl_vehicleinfo A,cp_cl_equipmentinfo B WHERE A.`pkID` = B.`fkID_VehicleInfo` AND B.`XuLieH` = new.ClientID;
	END IF;	
	/* 根据IC卡号查询人员主键、姓名、所属机构 */
	IF  new.ICNO = '' or new.ICNO is null THEN
		SET @ryID := '',@ryName := '';		
	ELSE		 
		SELECT `pkID`,`Name` INTO @ryID,@ryName FROM cp_ry_driverinfo WHERE ICNO = new.ICNO;	
	END IF;
	/* 设置当前行数据 */
	-- update `cp_yygl_serviceinfo` SET `fkID_Org` = @orgID,`fkID_VehicleInfo` = @clID,`fkID_DriverInfo` = @ryID,`CH_Name` = @ryName,`CH_CheHao` = @clNO where `pkID` = new.`pkID`;
	-- SET new.fkID_Org = @orgID,new.fkID_VehicleInfo = @clID,new.fkID_DriverInfo = @ryID,new.CH_Name = @ryName,new.CH_CheHao = @clNO;
	-- SET new.fkID_Org = @orgID,new.fkID_VehicleInfo = @clID,new.fkID_DriverInfo = @ryID,new.CH_Name = @ryName,new.CH_CheHao = @clNO;
	if length(IFNULL(new.`flagOn`,'')) > LENGTH(IFNULL(old.`flagOn`,'')) or LENGTH(IFNULL(new.`flagOff`,'')) > LENGTH(IFNULL(old.`flagOff`,'')) then
		/* 判断统计更新班次对应的营运数据图片是否阅读完毕 */
		SET @fgOn := SUBSTRING(IFNULL(new.`flagOn`,''),LENGTH(IFNULL(old.`flagOn`,''))+1); -- 获得上车照片阅读人员
		SET @fgOff := SUBSTRING(IFNULL(new.`flagOff`,''),LENGTH(IFNULL(old.`flagOff`,''))+1); -- 获得下车照片阅读人员
		SELECT COUNT(pkID) INTO @countAll FROM `cp_yygl_serviceinfo` WHERE `fkID_BanCiXX`=new.`fkID_BanCiXX`; -- 统计班次对应的所有营运数据
		SELECT COUNT(pkID) INTO @countOn FROM `cp_yygl_serviceinfo` WHERE `fkID_BanCiXX`=new.`fkID_BanCiXX` AND LOCATE(@fgOn,`flagOn`) > 0; -- 统计上车阅读数
		SELECT COUNT(pkID) INTO @countOff FROM `cp_yygl_serviceinfo` WHERE `fkID_BanCiXX`=new.`fkID_BanCiXX` AND LOCATE(@fgOff,`flagOff`) > 0; -- 统计下车阅读数
		IF @countAll =@countOn AND @countAll = @countOff THEN
			SET @fgAll := IF(@fgOn='' OR ISNULL(@fgOn)=1,@fgOff,@fgOn);
			UPDATE `cp_yygl_signinfosummary` SET `flagAll` = CONCAT(IFNULL(`flagAll`,''),@fgAll) WHERE `fkID_BanCiXX` = new.`fkID_BanCiXX` AND `ICNO` = new.`ICNO`;			
			-- 测试
			/*
			INSERT INTO centerserviceplatform.`temp_A`(a,b,c,d,e,f) 
			VALUES(CONCAT('@fgOn:',@fgOn),
			       CONCAT('@fgOff:',@fgOff),
			       CONCAT('@countAll:',IFNULL(CAST(@countAll AS CHAR),'')),
			       CONCAT('@countOn:',IFNULL(CAST(@countOn AS CHAR),'')),
			       CONCAT('@countOff:',IFNULL(CAST(@countOff AS CHAR),'')),
			       CONCAT('@flagAll:',@fgAll));
			 */		
		END IF;	
		/*if isnull(new.`flagOn`)=0 or isnull(new.`flagOff`)=0 or new.`flagOn`='' or new.`flagOff`='' then
		end if;*/	
	end if;	
    END;

