create
  definer = root@`%` procedure P_Stat_ZongYingShouXX(IN clientId varchar(30), IN ryStats varchar(10))
BEGIN
	if ryStats = 'zz' then	-- 在职人员
		SELECT A.`ClientID`,	      	       
		       A.`ICNO`,
		       A.`CH_Name`,
		       SUM(A.`serviceCount`) AS `serviceCount`,	-- 总营运次数
		       SUM(A.`amountMoney`) AS `amountMoney`,	-- 总营收金额
		       COUNT(*) AS `TotalBanCi`,		-- 总营运班次
		       SUM(A.workKilometre) AS `workKilometre`,	-- 总行驶里程
		       SUM(A.serviceKilometre) AS `serviceKilometre`, -- 总营运里程
		       SUM(A.cardCount) AS `cardCount`,		-- 总卡收次数
		       SUM(A.cardMoney) AS `cardMoney`,		-- 总卡收金额
		       SUM(TIMESTAMPDIFF(HOUR,A.`signInTime`,A.`signOutTime`)) AS `TotalTime`	-- 总营运时长
		  FROM centerserviceplatform.`cp_yygl_bancixx` A
		 WHERE A.`ClientID` = clientId
		   AND A.`fkID_DriverInfo` IN(SELECT pkID FROM cp_ry_driverinfo B WHERE B.`D_Status` = '1')
	      GROUP BY A.`ClientID`,A.`ICNO`,A.`CH_Name`;
	end if;	      	
	if ryStats = 'lz' then	-- 离职人员
		SELECT A.`ClientID`,	      	       
		       A.`ICNO`,
		       A.`CH_Name`,
		       SUM(A.`serviceCount`) AS `serviceCount`,	-- 总营运次数
		       SUM(A.`amountMoney`) AS `amountMoney`,	-- 总营收金额
		       COUNT(*) AS `TotalBanCi`,		-- 总营运班次
		       SUM(A.workKilometre) AS `workKilometre`,	-- 总行驶里程
		       SUM(A.serviceKilometre) AS `serviceKilometre`, -- 总营运里程
		       SUM(A.cardCount) AS `cardCount`,		-- 总卡收次数
		       SUM(A.cardMoney) AS `cardMoney`,		-- 总卡收金额
		       SUM(TIMESTAMPDIFF(HOUR,A.`signInTime`,A.`signOutTime`)) AS `TotalTime`	-- 总营运时长
		  FROM centerserviceplatform.`cp_yygl_bancixx` A
		 WHERE A.`ClientID` = clientId
		   AND A.`fkID_DriverInfo` IN(SELECT pkID FROM cp_ry_driverinfo B WHERE B.`D_Status` != '1')
	      GROUP BY A.`ClientID`,A.`ICNO`,A.`CH_Name`;
	else				-- 全部人员
		SELECT A.`ClientID`,	      	       
		       A.`ICNO`,
		       A.`CH_Name`,
		       SUM(A.`serviceCount`) AS `serviceCount`,	-- 总营运次数
		       SUM(A.`amountMoney`) AS `amountMoney`,	-- 总营收金额
		       COUNT(*) AS `TotalBanCi`,		-- 总营运班次
		       SUM(A.workKilometre) AS `workKilometre`,	-- 总行驶里程
		       SUM(A.serviceKilometre) AS `serviceKilometre`, -- 总营运里程
		       SUM(A.cardCount) AS `cardCount`,		-- 总卡收次数
		       SUM(A.cardMoney) AS `cardMoney`,		-- 总卡收金额
		       SUM(TIMESTAMPDIFF(HOUR,A.`signInTime`,A.`signOutTime`)) AS `TotalTime`	-- 总营运时长
		  FROM centerserviceplatform.`cp_yygl_bancixx` A
		 WHERE A.`ClientID` = clientId
		  -- AND A.`fkID_DriverInfo` IN(SELECT pkID FROM cp_ry_driverinfo B WHERE B.`D_Status` = '1')
	      GROUP BY A.`ClientID`,A.`ICNO`,A.`CH_Name`;	      
	end if;
    END;

