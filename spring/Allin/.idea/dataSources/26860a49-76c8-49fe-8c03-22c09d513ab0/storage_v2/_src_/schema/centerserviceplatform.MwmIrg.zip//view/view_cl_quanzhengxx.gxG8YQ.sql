create view view_cl_quanzhengxx as (select `qz`.`pkID`                            AS `pkId`,
                                           `qz`.`pkID`                            AS `code`,
                                           `qz`.`JingYingQZH`                     AS `description`,
                                           'cb5834b9-1b19-4d2f-8930-9ecc011bdadb' AS `TypeCode`
                                    from `centerserviceplatform`.`cp_b_jingyingqzxx` `qz`);

