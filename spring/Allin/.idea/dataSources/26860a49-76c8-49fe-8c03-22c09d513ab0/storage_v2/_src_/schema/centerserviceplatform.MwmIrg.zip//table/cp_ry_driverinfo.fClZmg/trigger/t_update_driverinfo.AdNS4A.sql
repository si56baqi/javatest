create definer = root@`%` trigger T_Update_DriverInfo
  before UPDATE
  on cp_ry_driverinfo
  for each row
BEGIN	
	SELECT `XuKeZH`,`OrgNO` INTO @xukezh,@orgno FROM cp_s_organization WHERE pkID = new.fkID_Org;	
	/*IF new.fkID_VehicleInfo = '' THEN
		SET @chehao := ''; -- @zhongduanNO := '';
	ELSE
		SELECT `NO` INTO @chehao FROM cp_cl_vehicleinfo WHERE pkID = new.fkID_VehicleInfo;
	END IF;*/
	/* 设置当前行数据 */
	SET new.CH_OrgXuKeZH = @xukezh, new.OrgNO = @orgno; -- new.CH_ZhongDuanNO = @zhongduanNO,new.CH_CheHao = @chehao;
    END;

