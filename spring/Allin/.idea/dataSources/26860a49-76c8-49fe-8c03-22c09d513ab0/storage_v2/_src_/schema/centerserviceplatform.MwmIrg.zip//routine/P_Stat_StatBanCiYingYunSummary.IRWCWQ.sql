create
  definer = root@`%` procedure P_Stat_StatBanCiYingYunSummary()
BEGIN
    
	-- 1.清空统计汇总表数据
	truncate table `stat_statbcyysummary`;
    
	-- 2.给统计汇总表里插入数据
	 INSERT INTO `stat_statbcyysummary`(`pkID`,`fkID_VehicleInfo`,`chehao`,`statYear`,`statMonth`,`banciCount`,`serviceCount`)
	 SELECT UUID() AS `pkID`,
		a.`fkID_VehicleInfo`,
		a.`CH_CheHao`,
		a.`n` AS `statYear`,
		a.`y` AS `statMonth`,
		-- concat(a.`n`,'-',a.`y`) as `statDate`,
		a.`cs` AS `banciCount`,
		b.`cs` AS `serviceCount`
	  FROM (SELECT YEAR(a.`meterOpenTime`) AS `n`,MONTH(a.`meterOpenTime`) AS `y`,a.`fkID_VehicleInfo`,a.`CH_CheHao`,COUNT(*) AS `cs` 
		  FROM centerserviceplatform.`cp_yygl_bancixx` a 
		 WHERE YEAR(a.`meterOpenTime`) = 2017
		 GROUP BY `n`,`y`,a.`CH_CheHao`,a.`fkID_VehicleInfo`) a,
		 (SELECT YEAR(a.`getOnCarTime`) AS `n`,MONTH(a.`getOnCarTime`) AS `y`,a.`fkID_VehicleInfo`,a.`CH_CheHao`,COUNT(*) AS `cs` 
		  FROM centerserviceplatform.`cp_yygl_serviceinfo` a
		 WHERE YEAR(a.`getOnCarTime`) = 2017
		 GROUP BY `n`,`y`,a.`CH_CheHao`,a.`fkID_VehicleInfo`
		 ) b
	 WHERE a.`n` = b.`n`
	   AND a.`y` = b.`y`
	   AND a.`fkID_VehicleInfo` = b.`fkID_VehicleInfo`
	 ORDER BY a.`n`,a.`y`,a.`CH_CheHao`;
 
    END;

