create view view_organization as
select `f`.`pkID`      AS `pkId`,
       `f`.`Name`      AS `name`,
       `f`.`ShortName` AS `shortName`,
       `f`.`NO`        AS `no`,
       `f`.`ParentID`  AS `parentId`,
       '机构'            AS `tclass`
from `centerserviceplatform`.`cp_s_organization` `f`;

