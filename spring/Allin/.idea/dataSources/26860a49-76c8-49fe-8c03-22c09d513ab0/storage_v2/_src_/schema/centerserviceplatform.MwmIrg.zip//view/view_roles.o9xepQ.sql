create view view_roles as
select `b`.`pkID` AS `pkId`, `b`.`Name` AS `name`, `b`.`NO` AS `nO`, '' AS `parentId`, '角色' AS `tclass`
from `centerserviceplatform`.`cp_s_userrole` `b`;

