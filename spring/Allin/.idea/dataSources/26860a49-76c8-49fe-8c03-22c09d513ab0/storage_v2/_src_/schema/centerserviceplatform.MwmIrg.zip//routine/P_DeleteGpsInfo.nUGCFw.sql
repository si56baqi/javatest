create
  definer = root@`%` procedure P_DeleteGpsInfo()
BEGIN
	SET @rq := CONCAT(CAST(DATE_ADD(CURDATE(), INTERVAL -1 DAY) AS CHAR), ' 23:59:59');
	SET @rqh := CONCAT(CAST(DATE_ADD(CURDATE(), INTERVAL -2 MONTH) AS CHAR), ' 23:59:59');
	SELECT COUNT(*) INTO @i FROM `cp_yyjk_gpsinfo` WHERE `receiverTime` <= @rq;
	IF @i > 0  THEN
		DELETE FROM `cp_yyjk_gpsinfo` WHERE 1 = 1 and `receiverTime` <= @rq; -- 一次删除1000条数据
		-- DELETE FROM `cp_yyjk_gpsinfoh` WHERE 1 = 1 AND `receiverTime` <= @rqh LIMIT 1000; -- 一次删除1000条数据
		-- delete from table_name where 1=1 order by order_name limit row_num;
	END IF;	
    END;

