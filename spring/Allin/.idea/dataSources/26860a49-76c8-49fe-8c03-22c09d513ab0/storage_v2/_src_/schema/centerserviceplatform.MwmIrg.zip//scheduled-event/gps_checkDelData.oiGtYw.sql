create definer = root@`%` event gps_checkDelData on schedule
  every '1' DAY
    starts '2018-04-03 00:00:00'
  on completion preserve
  enable
  do
  BEGIN
	CALL `P_DeleteGpsInfo`();
END;

