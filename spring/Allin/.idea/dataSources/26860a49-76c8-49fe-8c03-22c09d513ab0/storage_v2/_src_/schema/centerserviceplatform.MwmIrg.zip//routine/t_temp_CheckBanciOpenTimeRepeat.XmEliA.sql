create
  definer = root@`%` procedure t_temp_CheckBanciOpenTimeRepeat()
BEGIN
	/*
		测试用游标 遍历更新表数据
	*/ 
	-- 定义接收游标数据的变量 
	DECLARE clID VARCHAR(36);
	DECLARE openTime DATETIME;
	DECLARE clolseTime DATETIME;
	DECLARE iCount INT;
	
	/*
	DECLARE id CHAR(36);
	-- DECLARE ic CHAR(36);
	DECLARE sgInTime DATETIME;
	DECLARE sgOutTime DATETIME;
	DECLARE openTime DATETIME;
	DECLARE closeTime DATETIME;
	DECLARE sCount INT;
	DECLARE xlh CHAR(30);
	DECLARE clid CHAR(36);
	-- DECLARE lon DECIMAL(20,15);
	-- DECLARE lat DECIMAL(20,15);
	*/
	
	-- 游标结束标记
	DECLARE done INT DEFAULT 0;	
	-- 首先这里对游标进行定义
	DECLARE cur CURSOR FOR SELECT a.`fkID_VehicleInfo`,a.`meterOpenTime`,a.`meterCloseTime`,COUNT(a.`meterOpenTime`) AS `cs` FROM `cp_yygl_bancixx` a WHERE a.`serviceCount` >0 GROUP BY a.`fkID_VehicleInfo`,a.`meterOpenTime` HAVING cs > 1 ORDER BY cs DESC,a.`meterCloseTime` DESC;
	-- 这个是个条件处理,针对NOT FOUND的条件,当没有记录时赋值为1
	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1; 
	-- 使用OPEN打开游标
	OPEN cur;	
	-- 把第一行数据写入变量中,游标也随之指向了记录的第一行
	FETCH cur INTO clID, openTime, clolseTime, iCount;
	-- 开始遍历
	WHILE done != 1 DO	
		BEGIN
			DECLARE banciID VARCHAR(36);
			DECLARE banciCLID VARCHAR(36);
			DECLARE banciSigTime DATETIME;
			DECLARE banciOpenTime DATETIME;
			DECLARE banciCloseTime DATETIME;
			DECLARE banciSCount INT;
			DECLARE banciCarNum INT;
			
			-- declare tmpCount int;
			DECLARE iFlag INT;
		
			DECLARE doneSub INT DEFAULT 0;
			DECLARE curSub CURSOR FOR SELECT a.`pkID`,a.`fkID_VehicleInfo`,a.`signInTime`,a.`meterOpenTime`,a.`meterCloseTime`,a.`serviceCount`,a.`carNumber` FROM `cp_yygl_bancixx` a WHERE a.`meterOpenTime` = openTime AND a.`fkID_VehicleInfo` = clID ORDER BY a.`meterCloseTime` ASC;
			DECLARE CONTINUE HANDLER FOR NOT FOUND SET doneSub = 1;
			
			OPEN curSub;
			FETCH curSub INTO banciID,banciCLID,banciSigTime,banciOpenTime,banciCloseTime,banciSCount,banciCarNum;
			SET iFlag := 1;
			WHILE doneSub != 1 DO
				BEGIN
					IF iFlag = 1 THEN
						SELECT COUNT(*) INTO @tmpCount FROM `cp_yygl_serviceinfo` a WHERE a.`getOnCarTime` >= banciOpenTime AND a.`getOffCarTime` <= banciCloseTime AND a.`fkID_VehicleInfo` = clID;
						-- 1.更新营运数据对应的班次
						UPDATE `cp_yygl_serviceinfo` a SET a.`fkID_BanCiXX`= banciID WHERE a.`getOnCarTime` >= banciOpenTime AND a.`getOffCarTime` <= banciCloseTime AND a.`fkID_VehicleInfo` = clID;
						-- 2.更新校验班次信息数据					
						UPDATE `cp_yygl_bancixx` a SET a.`serviceCount`=@tmpCount,a.`carNumber`=@tmpCount WHERE a.`pkID` = banciID;
					ELSE
						SELECT COUNT(*) INTO @tmpCount FROM `cp_yygl_serviceinfo` a WHERE a.`getOnCarTime` >= banciSigTime AND a.`getOffCarTime` <= banciCloseTime AND a.`fkID_VehicleInfo` = clID;
						-- 1.更新营运数据对应的班次
						UPDATE `cp_yygl_serviceinfo` a SET a.`fkID_BanCiXX`= banciID WHERE a.`getOnCarTime` >= banciSigTime AND a.`getOffCarTime` <= banciCloseTime AND a.`fkID_VehicleInfo` = clID;
						-- 2.更新校验班次信息数据
						UPDATE `cp_yygl_bancixx` a SET a.`meterOpenTime` = banciSigTime,a.`serviceCount`=@tmpCount,a.`carNumber`=@tmpCount WHERE a.`pkID` = banciID;						
					END IF;
					
					SET iFlag := iFlag + 1;
					FETCH curSub INTO banciID,banciCLID,banciSigTime,banciOpenTime,banciCloseTime,banciSCount,banciCarNum;
				END;
			END WHILE;
			-- 关闭游标
			CLOSE curSub;	
			FETCH cur INTO clID, openTime, clolseTime, iCount;
		END;			
	END WHILE;	
	-- CLOSE把资源释放掉
	CLOSE cur;
	
    END;

