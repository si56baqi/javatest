create definer = root@`%` trigger T_Insert_DriverInfo
  before INSERT
  on cp_ry_driverinfo
  for each row
BEGIN
	select `XuKeZH`,`OrgNO` into @xukezh,@orgno from cp_s_organization where pkID = new.fkID_Org;
	IF new.fkID_VehicleInfo = '' THEN
		set @chehao := '';		
	else
		SELECT `NO` into @chehao from cp_cl_vehicleinfo where pkID = new.fkID_VehicleInfo;
		-- select `NO` INTO @zhongduanNO from cp_cl_equipmentinfo where fkID_VehicleInfo = new.fkID_VehicleInfo;		
	end if;	
	set new.CH_CheHao = @chehao, new.CH_OrgXuKeZH = @xukezh, new.OrgNO = @orgno;
	    -- new.CH_ZhongDuanNO = @zhongduanNO;
    END;

