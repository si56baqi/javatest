create view view_s_codetype as (select `a`.`TypeCode`                         AS `pkId`,
                                       `a`.`TypeCode`                         AS `code`,
                                       `a`.`TypeChineseDes`                   AS `description`,
                                       'bf490ddd-0903-11e6-ba11-e03f491c16cf' AS `typeCode`
                                from `centerserviceplatform`.`cp_s_codetypetable` `a`);

