create definer = root@`%` trigger T_Insert_VehicleInfo
  before INSERT
  on cp_cl_vehicleinfo
  for each row
BEGIN	
	-- SELECT `NO` INTO @chehao FROM cp_cl_vehicleinfo WHERE pkID = new.fkID_VehicleInfo;
	SELECT `XuKeZH`,`OrgNO` INTO @xukezh,@orgno FROM cp_s_organization WHERE pkID = new.fkID_Org;
	-- SELECT `NO` INTO @zhongduanNO FROM cp_b_equipmentinfo WHERE fkID_VehicleInfo = new.fkID_VehicleInfo;
	-- update cp_ry_driverinfo set CH_CheHao = @chehao where pkID = new.pkID;
	SET new.OrgNO = @orgno;
    END;

