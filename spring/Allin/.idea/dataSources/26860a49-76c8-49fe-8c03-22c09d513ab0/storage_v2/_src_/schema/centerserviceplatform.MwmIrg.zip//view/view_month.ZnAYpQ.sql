create view view_month as select 1 AS `no`, '1月' AS `name`, '一月' AS `description`
                          union
                          select 2 AS `no`, '2月' AS `name`, '二月' AS `description`
                          union
                          select 3 AS `no`, '3月' AS `name`, '三月' AS `description`
                          union
                          select 4 AS `no`, '4月' AS `name`, '四月' AS `description`
                          union
                          select 5 AS `no`, '5月' AS `name`, '五月' AS `description`
                          union
                          select 6 AS `no`, '6月' AS `name`, '六月' AS `description`
                          union
                          select 7 AS `no`, '7月' AS `name`, '七月' AS `description`
                          union
                          select 8 AS `no`, '8月' AS `name`, '八月' AS `description`
                          union
                          select 9 AS `no`, '9月' AS `name`, '九月' AS `description`
                          union
                          select 10 AS `no`, '10月' AS `name`, '十月' AS `description`
                          union
                          select 11 AS `no`, '11月' AS `name`, '十一月' AS `description`
                          union
                          select 12 AS `no`, '12月' AS `name`, '十二月' AS `description`;

